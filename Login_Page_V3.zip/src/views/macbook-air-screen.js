import React from 'react'

import { Helmet } from 'react-helmet'

import './macbook-air-screen.css'

const MacbookAirScreen = (props) => {
  return (
    <div className="macbook-air-screen-container">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="macbook-air-screen-macbook-air-screen">
        <div className="macbook-air-screen-register-frame">
          <img
            src="/playground_assets/registerbutton412-pqy7-200h.png"
            alt="Registerbutton412"
            className="macbook-air-screen-registerbutton button"
          />
          <span className="macbook-air-screen-text">Register Account</span>
        </div>
        <div className="macbook-air-screen-login-frame">
          <img
            src="/playground_assets/loginbutton410-rt65-200h.png"
            alt="Loginbutton410"
            className="macbook-air-screen-loginbutton button"
          />
          <span className="macbook-air-screen-text1">Login</span>
        </div>
        <div className="macbook-air-screen-password-frame">
          <img
            src="/playground_assets/passwordtextinput47-hzm-200h.png"
            alt="Passwordtextinput47"
            className="macbook-air-screen-passwordtextinput textarea"
          />
          <span className="macbook-air-screen-text2">
            <span>Password</span>
          </span>
        </div>
        <div className="macbook-air-screen-username-frame">
          <img
            src="/playground_assets/usernametextinput46-ilri-200h.png"
            alt="Usernametextinput46"
            className="macbook-air-screen-usernametextinput textarea"
          />
          <span className="macbook-air-screen-text4">
            <span>Username</span>
          </span>
        </div>
        <span className="macbook-air-screen-text6">
          <span>Login or Register</span>
        </span>
        <img
          src="/playground_assets/logo123-0k3h-300h.png"
          alt="Logo123"
          className="macbook-air-screen-logo"
        />
      </div>
    </div>
  )
}

export default MacbookAirScreen
